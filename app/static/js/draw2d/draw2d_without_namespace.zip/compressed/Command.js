/**
This notice must be untouched at all times.
This is the COMPRESSED version of Draw2D
WebSite: http://www.draw2d.org
Copyright: 2006 Andreas Herz. All rights reserved.
Created: 5.11.2006 by Andreas Herz (Web: http://www.freegroup.de )
LICENSE: LGPL
**/

Command=function(_6d7){this.label=_6d7;};Command.prototype.type="Command";Command.prototype.getLabel=function(){return this.label;};Command.prototype.canExecute=function(){return true;};Command.prototype.execute=function(){};Command.prototype.cancel=function(){};Command.prototype.undo=function(){};Command.prototype.redo=function(){};
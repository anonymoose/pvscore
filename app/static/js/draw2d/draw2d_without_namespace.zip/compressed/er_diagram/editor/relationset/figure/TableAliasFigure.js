/**
This notice must be untouched at all times.
This is the COMPRESSED version of Draw2D
WebSite: http://www.draw2d.org
Copyright: 2006 Andreas Herz. All rights reserved.
Created: 5.11.2006 by Andreas Herz (Web: http://www.freegroup.de )
LICENSE: LGPL
**/

TableAliasFigure=function(_7f2){TableFigure.call(this,_7f2.getTableModel());this.alias=_7f2;};TableAliasFigure.prototype=new TableFigure;TableAliasFigure.prototype.type="TableAliasFigure";TableAliasFigure.prototype.createHTMLElement=function(){var item=TableFigure.prototype.createHTMLElement.call(this);var row=this.table.insertRow(1);this.based=row.insertCell(0);this.based.innerHTML="Test";this.based.colSpan="2";this.based.style.background="transparent url(header.png) repeat-x";this.based.style.height="25px";this.based.style.paddingLeft="5px";this.based.style.paddingRight="5px";this.based.style.whiteSpace="nowrap";this.based.style.fontStyle="italic";this.based.style.color="rgb(100,100,100)";return item;};TableAliasFigure.prototype.setTableName=function(name){this.header.innerHTML=this.alias.getName();this.based.innerHTML="based on &lt;"+name+"&gt;";this.setDimension(this.getWidth(),this.getHeight());};
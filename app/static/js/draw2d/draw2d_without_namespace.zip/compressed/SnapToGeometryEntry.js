/**
This notice must be untouched at all times.
This is the COMPRESSED version of Draw2D
WebSite: http://www.draw2d.org
Copyright: 2006 Andreas Herz. All rights reserved.
Created: 5.11.2006 by Andreas Herz (Web: http://www.freegroup.de )
LICENSE: LGPL
**/

SnapToGeometryEntry=function(type,_aa8){this.type=type;this.location=_aa8;};SnapToGeometryEntry.prototype.getLocation=function(){return this.location;};SnapToGeometryEntry.prototype.getType=function(){return this.type;};
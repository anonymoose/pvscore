/**
This notice must be untouched at all times.
This is the COMPRESSED version of Draw2D
WebSite: http://www.draw2d.org
Copyright: 2006 Andreas Herz. All rights reserved.
Created: 5.11.2006 by Andreas Herz (Web: http://www.freegroup.de )
LICENSE: LGPL
**/

LineColorDialog=function(_4db){ColorDialog.call(this);this.figure=_4db;var _4dc=_4db.getColor();this.updateH(this.rgb2hex(_4dc.getRed(),_4dc.getGreen(),_4dc.getBlue()));};LineColorDialog.prototype=new ColorDialog();LineColorDialog.prototype.type="LineColorDialog";LineColorDialog.prototype.onOk=function(){var _4dd=this.workflow;ColorDialog.prototype.onOk.call(this);if(typeof this.figure.setColor=="function"){_4dd.getCommandStack().execute(new CommandSetColor(this.figure,this.getSelectedColor()));if(_4dd.getCurrentSelection()==this.figure){_4dd.setCurrentSelection(this.figure);}}};
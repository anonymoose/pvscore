/**
This notice must be untouched at all times.
This is the COMPRESSED version of Draw2D
WebSite: http://www.draw2d.org
Copyright: 2006 Andreas Herz. All rights reserved.
Created: 5.11.2006 by Andreas Herz (Web: http://www.freegroup.de )
LICENSE: LGPL
**/

PropertyChangeEvent=function(_a25,_a26,_a27,_a28){this.model=_a25;this.property=_a26;this.oldValue=_a27;this.newValue=_a28;};PropertyChangeEvent.prototype.type="PropertyChangeEvent";